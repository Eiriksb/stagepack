# slidev-pptx-export

Converts a [Slidev](https://sli.dev) markdown deck into a fully editable native `.pptx` -
real PowerPoint text boxes, tables, shapes and charts, not the screenshot-per-slide export
that `slidev export` produces.

https://github.com/user-attachments/assets/1b60f657-2fee-46d3-a69f-b893036e3c39

It understands plain markdown (headings, paragraphs, lists, tables, blockquotes, images,
fenced code blocks, `**bold**`/`*italic*`/`` `code` ``) plus a handful of common Slidev
authoring patterns: frontmatter-separated slides, Tailwind/UnoCSS grid layouts (`grid
grid-cols-N` -> a row of cards), `text-2xl`+ stat numbers, `opacity-NN` fades, and `<Vue
Component />` tags resolved into native charts via a `chartResolvers` config.

## What you get in PowerPoint

- **Real layouts and placeholders.** Slide titles sit in the layout's title placeholder, so
  outline view, the Accessibility Checker, Reset Slide and layout switching work. Text-only
  slides (paragraphs, bullets, sub-headings) put their body in the content placeholder, with
  native bullets and numbering and "shrink text on overflow". Slides with cards, tables, code,
  charts or images use the *Title Only* layout plus positioned shapes.
- **A theme built from your config.** `colors` and `fonts` become real theme colors and
  heading/body fonts in `theme1.xml`, and the slide master and layouts reference them the way
  a hand-built PowerPoint template would.
- **Slidev layouts mapped:** first slide / `cover` / `intro` → *Title Slide*, `center` / `end`
  → *Centered*, `section` → *Section Header*, everything else → *Title and Content* or *Title
  Only*.
- **Speaker notes** from the slide's last `<!-- ... -->` comment (Slidev's convention).
- **Native tables** styled by a deck table style, and **native charts** backed by an embedded
  Excel workbook that holds the chart's data, the way a chart built directly in PowerPoint is.
  A table too long for its slide continues on extra slides - same title plus "(cont.)", header
  row repeated - so the export can have more slides than the Slidev deck.
- **Overflow warnings:** content that still doesn't fit after shrinking to 55% prints a
  warning naming the slide, so you know which slides to split by hand.
- **Clean files:** content types and relationships are generated from the parts actually
  written, so nothing is orphaned or missing; `npm run render` round-trips every export
  through LibreOffice as a render check, and the same input always produces a byte-identical
  `.pptx`.

## Usage

```bash
npx slidev-pptx-export slides.md slides-editable.pptx
```

By default it looks for a `pptx.config.mjs` next to `slides.md` and merges it over the
built-in generic defaults. Pass `--config path/to/config.mjs` to use a different one.

Programmatic API:

```js
import { convert } from "slidev-pptx-export";

await convert({
  inputPath: "slides.md",
  outputPath: "slides-editable.pptx",
  config: { colors: { accent: "1A833B" } },
});

// Render mode (see below): runs the deck's own Slidev in headless Chromium.
await convert({ inputPath: "slides.md", outputPath: "slides-editable.pptx", render: true });

// Clicks and transitions for presenting (see Animations below).
await convert({ inputPath: "slides.md", outputPath: "slides-show.pptx", render: { animations: true } });
```

`render: { screenshots: true }` also returns Slidev's own screenshot of each exported slide as
`result.screenshots` (`null` for a slide exported from markdown), which the visual check uses. With
animations on they are all `null`: a slide there shows several states, so no one screenshot matches it.

## Render mode (`--render`)

By default the exporter reads only `slides.md`, so custom CSS, HTML and Vue components reach
the `.pptx` only through what `pptx.config.mjs` restates. With `--render` it instead runs the
deck with its own Slidev in headless Chromium and converts what is actually drawn:

```bash
npm i -D playwright-chromium   # once, in the deck folder (the package `slidev export` uses)
npx playwright install chromium
npx slidev-pptx-export slides.md slides-editable.pptx --render
```

- Text keeps its rendered font, size, weight, color, letter spacing and position; slide
  titles still go into title placeholders.
- Boxes with a background, border (solid, dashed or dotted; a single dashed side is a native line),
  rounded corners, shadow or gradient (cards, callouts) become native shapes; lists get native bullets in their rendered colors; tables become
  native tables with each cell's own fill and borders; code blocks keep their syntax colors
  (a block that scrolls or wraps in the page is a picture instead).
- A table scrolling in its box (or clipped by one) has the rows the page shows, since a slide can't
  scroll; a row cut off at the box's edge is left out.
- A card with a `backdrop-filter` keeps its contents native: under a nearly opaque fill (90% or more) it is
  a solid box, otherwise its blur is a picture behind them. A card holding a form control (a slider) is
  a picture as a whole.
- Chart.js bar charts (e.g. through vue-chartjs) become native, editable charts with the
  page's data, colors, axis range and number format; horizontal bars keep their order. Only
  charts PowerPoint can draw faithfully are native: for example, other chart types, mixed
  types, a log or second value axis, stack groups, a chart title, per-bar or scripted colors,
  and rotated or translucent charts are exported as pictures. A `chartResolvers` entry
  returning `kind: "barchart"` for the component still wins, also over a chart that would
  have been a picture.
- Videos become native PowerPoint videos: the file (MP4 or MOV) is embedded, cropped or letterboxed as
  the page draws it (`object-fit`), with its `poster` (else the frame shown) as the picture before it plays
  (an autoplaying video's own first frame: it is seen playing, and its poster may belong to another source).
  `autoplay` (the attribute, or `<SlidevVideo autoplay>`) starts it with the slide, `loop` repeats it until
  the slide is left and `muted` mutes it, the way PowerPoint writes *Start: Automatically* and *Loop until
  stopped*; without autoplay it plays when clicked. A video that is transformed, filtered, masked, clipped or
  in another format (WebM) stays a picture of its current frame, with a notice.
- Videos LibreOffice Impress can't show become looping animated GIFs in the same place, by default. Its
  slide show plays a video in a window of its own above the whole slide (slide content over a video, such
  as a cover's title over its background clip, is gone while it plays), and it shows one video per slide.
  So a muted video with content over it, and every muted video on a slide but its longest, is a GIF
  (PowerPoint, Impress, Keynote and Google Slides all play them). A GIF keeps the video's frame rate (up to
  30 a second). Impress decodes all of a GIF's frames before it shows the slide (about 19 million pixels a
  second), so each GIF is held to about 1.5 s of that: a background clip loops over a shorter stretch (at
  least 4 s) and then gets narrower; a clip of its own keeps its whole length and gets narrower (down to
  60 % of its size), then drops frames (to 15 a second at the fewest). It needs `ffmpeg` on the PATH
  (without it the videos stay videos, with a notice). `--videos native` (or `render: { videos: "native" }`)
  keeps them all as videos, for decks shown in PowerPoint only.
- `::before` / `::after` boxes and their text become native shapes and text boxes: a coloured square
  before a label, a numbered circle before a step (`counter()`, `counters()`, `list-item`, `attr()` and
  quoted strings; decimal, alpha and roman numbering), placed by `position: absolute` or as the flow puts
  them. An unsized pseudo-element with only text in the flow is left to the text around it.
- Images become native pictures; one that didn't load is skipped, with a notice. SVG images
  stay vector in PowerPoint 2016+ (with a PNG fallback elsewhere) when their box has the
  SVG's aspect, and are pictures otherwise. An image rounded with one radius all round (its own, or that of a
  box it fills which clips it) is a picture with a rounded-rectangle shape; other rounding (some corners,
  an image in one corner of a rounded box) is a picture of the page's drawing.
- A `url()` background is native only when it is centred cover/contain or 100% 100%. Any
  other background PowerPoint can't draw - an SVG, tiled or off-centre image, a translucent
  one, layered backgrounds, a repeating gradient, a radial gradient whose shape differs a lot
  from its box - becomes a picture behind the element's contents, which stay native text
  and shapes.
- `global-top.vue` and `global-bottom.vue` are exported with every slide (the bottom layer
  only where the slide lets it show through), so a shared footer usually lands on the slide
  master. A slide's `zoom:` is honoured: its text and shapes keep their zoomed size.
- Elements drawn identically on every slide, like a footer logo, go on the slide master once,
  unless slide content covers them. A picture there is reported as "slide master".
- Anything PowerPoint can't express natively (blur and other CSS filters, masks, inline SVG
  drawings, other canvases, and the cases above) is drawn as a picture of just that element,
  with a notice naming the slide. What the slide draws over it stays out of the picture and native;
  what lies beneath shows in it. An element running past the slide's edges (a Leaflet map's overlay)
  is pictured as far as it is on the slide, and a picture wholly under a later one is left out.
- Where elements overlap they keep the page's stacking order (`z-index`, stacking contexts); elsewhere
  shapes follow the DOM order, which is PowerPoint's reading order.
- `colors` and `fonts` in `pptx.config.mjs` still build the theme (rendered colors that match
  become theme colors); `logo`, `eyebrowClass` and `cssVarColors` aren't needed, and a notice
  says they are ignored when the config sets them. `render: { timeout }` sets the per-slide
  wait (default 15000 ms). The first slide also waits for Slidev's cold start (Vite
  dependency optimisation), so slow machines or heavy decks may need a larger timeout.
- A slide Slidev can't load or render falls back to the markdown export, with a warning. A
  slide imported from another file (`src:`) has no markdown fallback (the default mode
  doesn't read imported files), so it is left blank, with a warning. When Slidev can't start
  (for example its theme isn't installed), Chromium can't launch or the Slidev version isn't
  supported, the export stops with an error instead; Chromium is launched before Slidev
  starts, so a missing browser fails fast.
- Each slide is captured once its scripts have stopped changing it and its images have loaded, so a
  map that flies into place or a route drawn by `requestAnimationFrame` is exported finished. One still
  changing after `render: { timeout }` is exported as it stands, with a notice.
- Limits: each slide is captured in its final `v-click` state, with every fragment shown.
  Animations and transitions (videos excepted, see above; `--animations` below carries them over), hyperlinks (link text keeps its styling) and Slidev
  drawings aren't carried over; fonts only with `--embed-fonts` (see Fonts).

Render mode needs the deck's dependencies installed (`npm install` in the deck folder), Node
20.12 or newer (what Slidev 52 requires) and Playwright's Chromium. It looks for
`playwright-chromium`, then `playwright`, each first in the deck folder and then next to this
package. It takes roughly 10–30 seconds per deck.

### Choosing the browser and ffmpeg

By default the browser is Playwright's Chromium. To drive another Chromium-family browser (Chrome, Edge,
Chromium from a package manager) name its executable, in `pptx.config.mjs` or the environment:

```js
export default { render: { browser: "/usr/bin/chromium", ffmpeg: "/opt/ffmpeg/bin/ffmpeg" } };
```

```bash
SLIDEV_PPTX_BROWSER=/usr/bin/chromium SLIDEV_PPTX_FFMPEG=/opt/ffmpeg/bin/ffmpeg \
  npx slidev-pptx-export slides.md slides-editable.pptx --render
```

- `render.browser` / `SLIDEV_PPTX_BROWSER` names the executable. `playwright-core` is enough to drive it, so
  Playwright's own download isn't needed; if `playwright-chromium` or `playwright` is installed, that is
  used first.
- `render.ffmpeg` / `SLIDEV_PPTX_FFMPEG` is the ffmpeg used for recorded clips (`--animations`) and for
  the animated pictures of a deck's own videos. For clips, a named ffmpeg that is missing or lacks
  `libx264` gives way to `ffmpeg` on the PATH, then GStreamer. For the animated pictures only the named
  ffmpeg is used (`ffmpeg` on the PATH when none is named); if it isn't there, those videos stay videos, with a notice.
- A key in the config wins over its environment variable.

### Progress (`--progress json`)

With `--progress json` stdout carries only the export's progress, one JSON object per line, for a program
that runs the exporter and shows it. What the export says for people (`Notice:` and `Warning:` lines,
errors) stays on stderr.

| `event` | When | Other fields |
| --- | --- | --- |
| `start` | the deck is open | `slides` |
| `slide` | a slide is being captured | `slide`, `states` (1 + its clicks, with `--animations`) |
| `state` | one state of a slide is captured | `slide`, `state` (0 is the first) |
| `record` | a click is being recorded | `slide`, `click` |
| `clip` | a click's recording is encoded | `slide`, `click`, `seconds`, `bytes` |
| `notice` | the export printed a warning | `text` |
| `write` | the file is being written | |
| `done` | the file is written | `path`, `slides`, `clips`, `bytes` |
| `error` | the export failed (always the last line) | `message` |

The `.pptx` is written as `<out>.partial` and renamed when complete, so a file with the final name is
whole.

### From a .sptx

[Stagepack](https://github.com/Eiriksb/stagepack) packs a Slidev presentation into one `.sptx` file. Its
installers bring this exporter, a headless browser and ffmpeg, and add *Export to PowerPoint (editable)*
and *Export to PowerPoint (with animations)* to the `.sptx` right-click menu. They use the options above
to name the browser and ffmpeg they installed and to follow the export's progress.

## Animations (`--animations`)

```bash
npx slidev-pptx-export slides.md slides-show.pptx --animations
```

`--animations` (or `render: { animations: true }` in `pptx.config.mjs`, or `render: { animations: true }`
in `convert`) is render mode that also carries the deck's clicks and slide transitions over, so the
`.pptx` steps through them in the slide show in the same order as Slidev. It is made for presenting
from **PowerPoint for the web** with a **keyboard or clicker**. Keep the default export as the copy you
edit: this one is for presenting.

What becomes what:

- A click that only shows, hides or changes content (`v-click`, a `$clicks`-driven component, a table
  that gains a column) is a native Fade on the same slide. Text and tables stay native.
- A click after which the page moves by script for a while (a map flying, a route being drawn, anything
  run by `requestAnimationFrame` or `setInterval`) and a picture on the slide changes (a map, a canvas,
  an SVG drawing) is recorded frame by frame and becomes a slide of its own holding a
  video of the whole slide, which starts by itself and holds its last frame. Script motion that changes
  only text or boxes (a number counting up) is a Fade to its end state. Everything on that slide,
  text and tables included, is part of the video: on PowerPoint for the web, native shapes above a
  video vanish on later video slides of a show, so there is nothing above it. The next click opens a
  native slide again, fading in.
- A click that changes the slide's background also opens a new slide, fading in: PowerPoint can't
  change a background on a click.
- The deck's `transition` (a name, or `{ name }`) becomes PowerPoint's Fade for `fade` and `fade-out`,
  and Push for `slide-left`, `-right`, `-up` and `-down`. Others (`view-transition`, custom ones) get
  none, with a notice.
- A deck therefore has more PowerPoint slides than Slidev slides: one more per click that moves.
  Speaker notes are on all of them.
- Nothing goes on the slide master, and the deck's own videos stay videos (`--videos` doesn't apply).

Use a keyboard or clicker. A mouse click on a video slide restarts the video instead of moving on.
Going back with the left arrow works, but each video slide takes one extra press. Large pictures are
JPEGs in this mode, so slides appear faster after a change.

Recording a click needs **ffmpeg** with `libx264`, or **GStreamer** with `x264enc` and `mp4mux` (on
Debian and Ubuntu: `gstreamer1.0-plugins-ugly` and `gstreamer1.0-plugins-good`). Without one, such a
click is a Fade to its end state, with a notice naming what to install. Each recorded click prints its
length and size; the test deck's took 2 to 15 seconds and 0.6 to 3.6 MB each. An export takes a few
minutes, mostly recording. A recording waits for its page as long as `render: { timeout }` (at least
30 s), and a click whose page is still moving after 40 s is a Fade, with a notice.

What can't carry over: hover highlights, live sliders and other controls, scrolling inside a table, and
motion that runs when a slide opens without a click (the slide shows its settled state).

Checked on PowerPoint for the web in Chromium on Linux, by running a whole deck from the first slide.
Not checked: desktop PowerPoint, Keynote, Google Slides and Presenter View. LibreOffice Impress opens
the file. Known quirks on the web:

- A slide's video that you change in PowerPoint's editor (its Start setting, for instance) may stop
  starting by itself, even after you change it back.
- Pressing Escape while a video plays can leave its frame over the editor until the page is reloaded.
- A notice saying a clip's last frame differs from a fresh load of the slide means the page ends a
  click differently from how it loads at that click. The video shows what the page did; the next slide
  shows the fresh load. Usually that is the deck's own doing (a layout that isn't updated while
  something moves), worth fixing in the deck.

## Fonts (`--embed-fonts`)

```bash
npx slidev-pptx-export slides.md slides.pptx --render --embed-fonts
```

The fonts the slides use are carried in the `.pptx`, so it looks the same on a machine without them:
regular, bold, italic and bold italic of each family, as Embedded OpenType (`/ppt/fonts/*.fntdata`, what
PowerPoint itself writes), listed in the presentation's `embeddedFontLst`.

- Each font name is looked up with fontconfig (`fc-match`). A web font's name that no installed font has
  ("Inter Variable", as `@fontsource-variable` calls Inter) falls back to the family without " Variable",
  and the slides are written with that family's name, the one inside the embedded font.
- Only TrueType fonts whose licence allows embedding (OS/2 `fsType` not restricted) are embedded;
  PostScript-outline (CFF) fonts and restricted ones are left out with a notice, as are names no installed
  font has (like Arial on Linux: a theme default every PowerPoint machine has).
- Fonts that aren't installed can be given in the config:

```js
export default {
  embedFonts: {
    aliases: { "JetBrains Mono Variable": "JetBrains Mono" },
    files: { "JetBrains Mono": { regular: "fonts/JetBrainsMono-Regular.ttf", bold: "fonts/JetBrainsMono-Bold.ttf" } },
  },
};
```

## Config

A config file's default export is deep-merged over the built-in defaults
(`src/default-config.mjs`). Nothing is required - with no config at all you get a plain,
readable deck in a neutral color scheme.

```js
// pptx.config.mjs
export default {
  slide: { width: 13.333, height: 7.5, marginX: 0.6 }, // inches; 13.333x7.5 = 16:9

  colors: {
    accent: "2563EB",     // eyebrow label, cover subtitle color, chart accents
    accentDark: "1E3A8A", // headings, **bold**, `code`
    accent2: "7C3AED",    // cover title
    panel: "F1F5F9",      // card/table-header backgrounds
    border: "E2E8F0",
    text: "1F2937",
    muted: "6B7280",      // faded/opacity-NN text
  },

  fonts: { heading: "Arial", body: "Arial", mono: "Courier New" },

  lang: "en-US",     // language tag on every text run (spell-check)
  timestamps: false, // true = write the export time into the file (breaks byte-identical output)

  // Inline style="color: var(--x)" -> one of the color keys above, for decks that color
  // text via CSS variables rather than Tailwind classes.
  cssVarColors: { "--brand-blue": "accent2" },

  // <div class="..."> that renders as the small uppercase label above a slide's title.
  eyebrowClass: "eyebrow",

  // Footer logo drawn bottom-left on every slide, or omit/null for none. Slide bodies end
  // 0.1in above it, so content never runs into the logo.
  logo: { path: "./assets/logo.png", aspect: 598 / 165, height: 0.27 },

  // Directory (relative to the input .md) chart resolvers may read data from.
  dataDir: "public/data",

  // <ComponentName /> tag -> (dataDirPathOrNull) => ResolvedChart | null
  chartResolvers: {
    MyChart(dataDir) {
      /* read dataDir/whatever.json yourself, shape it into one of: */
      return { kind: "statcards", cards: [{ title: "...", stats: [{ value: "42%", label: "..." }] }] };
      // or: { kind: "barchart-panels", panels: [{ title, color, rows: [{ model, success }] }], min: 0, max: 100 }
      // or: { kind: "barchart", labels: [...], datasets: [{ name, color, data: [...] }], min: 0, max: 100 }
    },
  },
};
```

A component tag with no matching resolver (or whose resolver throws / returns `null`)
renders as a labeled placeholder box instead of failing the whole export.

## Development

```bash
npm test                    # unit tests, package lint, kitchen-sink fixture export
npm run render              # LibreOffice render of the fixture (and ../innotek-SlideDevBase if present) to out/render/
npm run test:render         # browser tests (needs playwright-chromium; skips otherwise)
npm run render -- --render  # render-mode export + visual check against Slidev's own screenshots
npm --prefix test/fixtures/animated-deck ci   # once: the Slidev the --animations tests run
```

The browser tests (`test/render/`) use `playwright-chromium` and `chart.js`, both
devDependencies; `chart.js` is only there to draw test charts. `npm test` needs no
browser. The render checks skip when LibreOffice, poppler or Chromium isn't available.
The `--animations` tests export a small deck with its own Slidev (`test/fixtures/animated-deck`), and
skip until it is installed; a clip's colours are checked in Google Chrome, which can decode H.264, and
that test skips without it.

## What it doesn't do

The default mode is a markdown -> pptx layout engine tuned for the patterns Slidev decks
commonly use, not a full HTML/CSS renderer. Arbitrary nested HTML, custom Vue components
without a resolver, and complex CSS layouts fall back to a flattened, best-effort text
rendering. `--render` converts what the page draws instead, so custom HTML, CSS and Vue
components come through (see Render mode above for its limits).

In the default mode only PNG/JPEG/GIF images and logos embed natively; an SVG image exports
as a labeled placeholder and an SVG logo is skipped (`--render` embeds SVG images, see
above). A `layout: section` slide whose body is more than plain text/bullets (a table, chart
or card row) uses the *Title Only* layout instead of *Section Header*, since that content
doesn't fit the section body placeholder.
