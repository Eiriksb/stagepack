// Public API: convert(options) turns a Slidev markdown deck into a fully editable native
// .pptx - real PowerPoint placeholders, text, tables, shapes and charts on a themed slide
// master, not the screenshot-per-slide export `slidev export` produces. See README.md for the
// config shape and bin/cli.mjs for the command-line wrapper.

import { readFileSync, existsSync } from "node:fs";
import { resolve, dirname, basename, extname } from "node:path";
import { mergeConfig } from "./config.mjs";
import { splitSlides, parseSlide } from "./parse.mjs";
import { layoutDeck, deckStyle } from "./layout.mjs";
import { writePptx } from "./ooxml/index.mjs";
import { fontResolver } from "./fonts.mjs";
import { writeAtomic } from "./write.mjs";

const LOGO_EXTS = new Set([".png", ".jpg", ".jpeg", ".gif"]);

// The footer logo config with its path resolved, or null when none is configured or the file
// is missing or isn't a format PowerPoint embeds natively. Resolved before layout, because the
// slide geometry reserves footer space only for a logo that will actually be drawn.
function usableLogo(logo, configDir) {
  if (!logo || !logo.path) return null;
  const path = resolve(configDir, logo.path);
  if (!existsSync(path)) return null;
  if (!LOGO_EXTS.has(extname(path).toLowerCase())) {
    console.warn(`Warning: logo ${path} is not PNG/JPEG/GIF - skipped.`);
    return null;
  }
  return { ...logo, path };
}

/**
 * @param {object} options
 * @param {string} options.inputPath - path to the deck's .md file
 * @param {string} [options.outputPath] - defaults to "<input-basename>-editable.pptx" next to inputPath
 * @param {object} [options.config] - see default-config.mjs; typically loaded from a deck's pptx.config.mjs
 * @param {string} [options.configDir] - directory config-relative paths (logo.path) resolve against; defaults to inputPath's directory
 * @param {boolean} [options.embedFonts] - embed the fonts the slides use (TrueType, licence permitting; see README "Fonts")
 * @param {boolean} [options.handleSignals] - `false` turns off Playwright's own SIGINT/SIGTERM handling in render mode, for a caller that stops the export itself (the CLI); default true
 * @param {(event: object) => void} [options.onProgress] - called with each progress event: start, slide, state, record, clip, write, done
 * @param {boolean|{screenshots?: boolean, animations?: boolean}} [options.render] - render the deck with its own Slidev in Chromium and convert what is drawn (see README "Render mode"). `animations`, here or as `config.render.animations`, implies render mode and plays the deck's clicks and transitions in the slide show (see README "Animations")
 * @returns {Promise<{ outputPath: string, slideCount: number, clips: number, bytes: number, translatedCharts: number, unresolvedCharts: string[], screenshots?: (Buffer|null)[] }>}
 *   `screenshots` (render mode with `screenshots: true`): Slidev's own screenshot of each exported slide, null for a slide exported from markdown, and all null with animations on
 */
export async function convert(options) {
  const onProgress = options.onProgress || (() => {});
  const inputPath = resolve(options.inputPath);
  const raw = readFileSync(inputPath, "utf8");
  const inputDir = dirname(inputPath);
  const configDir = options.configDir ? resolve(options.configDir) : inputDir;

  const config = mergeConfig(options.config || {});
  // Animations imply render mode, whichever way they were asked for.
  if (options.render?.animations) config.render = { ...config.render, animations: true };
  const render = options.render || (config.render?.animations ? {} : false);
  config.inputDir = inputDir;
  config.publicDir = resolve(inputDir, "public");
  if (!existsSync(config.publicDir)) config.publicDir = null;

  const dataDir = resolve(inputDir, config.dataDir);
  config.resolvedDataDir = existsSync(dataDir) ? dataDir : null;
  if (!config.resolvedDataDir && Object.keys(config.chartResolvers).length) {
    console.warn(`Warning: data directory "${config.dataDir}" not found next to ${basename(inputPath)} - charts will fall back to placeholders.`);
  }

  // Render mode draws whatever logo the page shows, so the config's logo isn't used there.
  config.logo = render ? null : usableLogo(config.logo, configDir);

  const { globalFrontmatter, slides } = splitSlides(raw);
  const codeStore = [];
  const parsed = slides.map((s) => ({ ...parseSlide(s.content, codeStore, config), frontmatter: s.frontmatter }));
  const chartBlocks = parsed.flatMap((s) => s.blocks).filter((b) => b.type === "chart");

  let specs;
  let style;
  let rendered = null;
  if (render) {
    // Loaded only here: the static export never touches the browser pipeline.
    const { renderSpecs } = await import("./render/index.mjs");
    rendered = await renderSpecs({ inputPath, userConfig: options.config || {}, config, parsed, codeStore, screenshots: render.screenshots === true, handleSignals: options.handleSignals, onProgress });
    ({ specs, style } = rendered);
  } else {
    specs = layoutDeck(parsed, codeStore, config);
    style = deckStyle(config);
  }

  onProgress({ event: "write" });
  const buffer = await writePptx(specs, {
    geometry: style.geometry,
    theme: style.theme,
    fonts: config.fonts,
    lang: config.lang,
    title: globalFrontmatter.title || basename(inputPath, extname(inputPath)),
    author: config.author,
    timestamps: config.timestamps === true,
    // Drawn bottom-left on every slide via the slide master.
    logo: config.logo ? { path: config.logo.path, box: style.geometry.logo } : null,
    masterShapes: rendered ? rendered.masterShapes : [],
    // --embed-fonts / embedFonts: the fonts the slides use, carried in the file
    fontResolver: options.embedFonts || config.embedFonts?.enabled ? fontResolver(config.embedFonts || {}, configDir) : null,
  });

  const outputPath = resolve(options.outputPath || `${basename(inputPath, extname(inputPath))}-editable.pptx`);
  await writeAtomic(outputPath, buffer);
  const clips = rendered?.clips ?? 0;
  onProgress({ event: "done", path: outputPath, slides: specs.length, clips, bytes: buffer.length });

  // specs, not parsed slides: a long table can continue onto extra slides.
  const result = {
    outputPath,
    slideCount: specs.length,
    clips,
    bytes: buffer.length,
    translatedCharts: rendered ? rendered.translatedCharts : chartBlocks.filter((b) => b.resolved).length,
    unresolvedCharts: rendered ? [] : [...new Set(chartBlocks.filter((b) => !b.resolved).map((b) => b.name))],
  };
  if (rendered && render.screenshots === true) result.screenshots = rendered.screenshots;
  return result;
}

export { mergeConfig } from "./config.mjs";
export { defaultConfig } from "./default-config.mjs";
