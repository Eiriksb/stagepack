// Render mode's capture for an animated export: every click state of every slide, directly loaded as
// /<n>?clicks=k, and a clip for each click whose page moves by script.

import { readFileSync, rmSync } from "node:fs";
import { join } from "node:path";
import { clickKind, pictureChanged } from "./animation-plan.mjs";
import { captureSlide, openDeck } from "./capture.mjs";
import { changedShare } from "./compare.mjs";
import { ENCODER_HINT, encodeClip, findEncoder } from "./encode.mjs";
import { clipFrame, recordClick } from "./record.mjs";

// Above this share of clearly changed pixels, a clip's last frame isn't what a fresh load of that state
// shows. Measured on a real deck's twelve clips: those that end right change 0.005 to 0.009%; the state
// before each click, against the fresh load after it, 0.12 to 7%.
const DIFFERENT_ENDING = 0.0005;
// A recording page loads the slide's state before the click and waits for it to settle, which can take
// longer than a still capture: at least this long, or render.timeout when that is longer.
const RECORD_TIMEOUT_MS = 30000;

const firstLine = (err) => String(err?.message || err).split("\n")[0];
const frameFile = (dir, i) => join(dir, `f${String(i).padStart(5, "0")}.jpg`);

// `nav.clicksTotal` is a number or, depending on how Slidev exposes it, a ref.
const clicksTotal = (page) =>
  page.evaluate(() => {
    const total = window.__slidev__?.nav?.clicksTotal;
    return Number(total && typeof total === "object" ? total.value : total) || 0;
  });

// `announced` records how far the progress events have got, so a failure part way leaves them consistent.
async function statesOf(page, baseUrl, s, canvas, timeout, onProgress, announced) {
  const at = (k) => ({ url: `${baseUrl}/${s.no}?clicks=${k}`, jpeg: true });
  const states = [await captureSlide(page, baseUrl, s, canvas, true, timeout, at(0))];
  const total = await clicksTotal(page);
  onProgress({ event: "slide", slide: s.no, states: total + 1 });
  announced.slide = true;
  onProgress({ event: "state", slide: s.no, state: 0 });
  for (let k = 1; k <= total; k++) {
    states.push(await captureSlide(page, baseUrl, s, canvas, true, timeout, at(k)));
    onProgress({ event: "state", slide: s.no, state: k });
  }
  return states;
}

// A click that changed a picture: records it to see whether the page moves by script, and if it does,
// makes the clip. Anything that goes wrong costs the clip, not the export: the click is then a Fade.
async function recordedClick({ page, baseUrl, s, k, canvas, state, timeout, record, encoder, encode, notice, onProgress }) {
  const where = `slide ${s.no} click ${k}`;
  const reveal = { kind: "reveal" };
  let rec;
  onProgress({ event: "record", slide: s.no, click: k });
  try {
    rec = await record({ browser: page.context().browser(), url: `${baseUrl}/${s.no}?clicks=${k - 1}`, sel: `.slidev-page-${s.no}`, canvas, timeout: Math.max(timeout, RECORD_TIMEOUT_MS) });
  } catch (err) {
    notice(`Notice: ${where}: couldn't record it (${firstLine(err)}) - exported as a Fade.`);
    return reveal;
  }
  try {
    const { kind, reason } = clickKind({ changed: true, record: rec, encoder });
    if (kind === "reveal") {
      if (reason) notice(`Notice: ${where}: ${reason}${encoder ? "" : ` (${ENCODER_HINT})`} - exported as a Fade.`);
      return reveal;
    }
    const data = encode(encoder, rec);
    const changed = await changedShare(page, readFileSync(frameFile(rec.dir, rec.count - 1)), state.screenshot);
    if (changed > DIFFERENT_ENDING) notice(`Notice: ${where}: the clip's last frame differs from a fresh load of the slide (the page's live state differs from a fresh load, or a recording is wrong).`);
    const duration = rec.count / rec.fps;
    onProgress({ event: "clip", slide: s.no, click: k, seconds: Math.round(duration * 10) / 10, bytes: data.length });
    notice(`Notice: ${where}: clip, ${duration.toFixed(1)} s, ${(data.length / 2 ** 20).toFixed(1)} MB.`);
    const { width, height } = clipFrame(canvas);
    return { kind: "motion", clip: { data, poster: readFileSync(frameFile(rec.dir, 0)), duration, natural: { w: width, h: height } } };
  } catch (err) {
    notice(`Notice: ${where}: couldn't make a clip (${firstLine(err)}) - exported as a Fade.`);
    return reveal;
  } finally {
    rmSync(rec.dir, { recursive: true, force: true });
  }
}

async function captureOne({ page, baseUrl, s, canvas, timeout, record, encoder, encode, notice, onProgress }) {
  const source = { index: s.no, sourceIndex: s.sourceIndex, filepath: s.filepath };
  const slide = { ...source, notes: s.notes, transition: s.transition };
  let states;
  const announced = { slide: false };
  try {
    states = await statesOf(page, baseUrl, s, canvas, timeout, onProgress, announced);
  } catch (err) {
    try {
      const final = await captureSlide(page, baseUrl, s, canvas, false, timeout, { jpeg: true });
      // What was announced no longer holds: the slide is exported as its one final state.
      onProgress({ event: "slide", slide: s.no, states: 1 });
      if (!announced.slide) onProgress({ event: "state", slide: s.no, state: 0 });
      notice(`Notice: slide ${s.no}: its click states couldn't be captured (${firstLine(err)}) - exported in its final state.`);
      return { ...slide, states: [final], clicks: [] };
    } catch (failed) {
      return { ...source, error: firstLine(failed) };
    }
  }
  const clicks = states.length > 1 ? [null] : [];
  for (let k = 1; k < states.length; k++) {
    const changed = pictureChanged(states[k - 1].nodes, states[k].nodes);
    clicks.push(changed ? await recordedClick({ page, baseUrl, s, k, canvas, state: states[k], timeout, record, encoder, encode, notice, onProgress }) : { kind: "reveal" });
  }
  for (const state of states) delete state.screenshot;
  return { ...slide, states, clicks };
}

// { canvas, slides }. A slide is { index, sourceIndex, filepath, notes, transition, states, clicks }, with
// clicks[k] for k >= 1 being { kind: "reveal" } or { kind: "motion", clip: { data, poster, duration, natural } };
// or, when it couldn't be captured, { index, sourceIndex, filepath, error }.
export async function captureClickStates({ baseUrl, browser, timeout = 15000, slidevVersion = "unknown", record = recordClick, encoder = findEncoder(), encode = encodeClip, notice = console.warn, onProgress = () => {} }) {
  const page = await browser.newPage({ viewport: { width: 980, height: 552 }, deviceScaleFactor: 2 });
  try {
    page.setDefaultTimeout(timeout);
    const { canvas, list } = await openDeck(page, baseUrl, timeout, slidevVersion);
    onProgress({ event: "start", slides: list.length });
    const slides = [];
    for (const s of list) slides.push(await captureOne({ page, baseUrl, s, canvas, timeout, record, encoder, encode, notice, onProgress }));
    return { canvas, slides };
  } finally {
    await page.close();
  }
}
